    /* REQUÊTE A1 / A2 */
/*(a) Nombre de survivants, respectivement de victimes parmi les passagers, selon leur classe (une requête par classe) */

SELECT (
    select count(*)  
    from passenger 
    where pclass=1
    and survived=1
    )as nb_survivants_class1
    ,
    (select count(*)  
    from passenger 
    where pclass=1
    and survived=0
    )as nb_victimes_class1

;

SELECT (
    select count(*)  
    from passenger 
    where pclass=2
    and survived=1
    )as nb_survivants_class2
    ,
    (select count(*)  
    from passenger 
    where pclass=2
    and survived=0
    )as nb_victimes_class2

;

SELECT (
    select count(*)  
    from passenger 
    where pclass=3
    and survived=1
    )as nb_survivants_class3
    ,
    (select count(*)  
    from passenger 
    where pclass=3
    and survived=0
    )as nb_victimes_class3

;
/*(b) Nombre de survivants, respectivement de victimes parmi les passagers, selon leur catégorie (enfant, femme ou
homme – une requête par catégorie) ? */

/*Par Catégorie*/
select (
    SELECT count(*) 
    FROM PASSENGER 
    WHERE Age < 12 
        AND Survived = 1)as nb_survivants_enfants
,(
    SELECT count(*) 
    FROM PASSENGER 
    WHERE Age < 12 
        AND Survived = 0)as nb_victimes_enfants
;

select (
    SELECT count(*)  
    FROM PASSENGER 
    WHERE Sex = 'female' 
        AND Age >= 12 
        AND Survived = 1)as nb_survivants_femmes
,(
    SELECT count(*)  
    FROM PASSENGER 
    WHERE Sex = 'female' 
        AND Age >= 12 
        AND Survived = 0)as nb_victimes_femmes
;

select (
    SELECT count(*)  
    FROM PASSENGER 
    WHERE Sex = 'male' 
        AND Age >= 12 
        AND Survived = 1)as nb_survivants_hommes
,(
    SELECT count(*)  
    FROM PASSENGER 
    WHERE Sex = 'male' 
        AND Age >= 12 
        AND Survived = 0)as nb_victimes_hommes
;

/*NOMBRE TOTAL DE :*/
/*Survivant*/

SELECT (
    SELECT count(*) 
    FROM PASSENGER 
    WHERE Survived = 1) as nbTotal_survi
,(
    SELECT count(*) 
    FROM PASSENGER 
    WHERE Age < 12 
        AND Survived = 1)
+(
    SELECT count(*) 
    FROM PASSENGER 
    WHERE Age >= 12 
        AND Survived = 1) as nb_survivants
;

/*Victimes*/

SELECT (
    SELECT count(*) 
    FROM PASSENGER 
    WHERE Survived = 0) as nbTotal_victime
,(
    SELECT count(*) 
    FROM PASSENGER 
    WHERE Age < 12 
        AND Survived = 0)
+(
    SELECT count(*) 
    FROM PASSENGER 
    WHERE Age >= 12 
        AND Survived = 0) as nb_victimes
;


    /* REQUÊTE A3 */

/*(a) Taux de survivants par classe, toutes catégories confondues (enfants, femmes ou hommes) */

/* Requête pous savoir combien de personne par classe */

select pclass, count(*)as nb_pers_par_classe
from passenger 
group by pclass
;

/* Requêtes pour avoir le nombre de survivants par classe */

select pclass, count(*)as nb_surv_par_classe
from passenger 
where survived=1
group by pclass
;

/* requêtes principales */

SELECT DISTINCT PClass, round(
    (SELECT count(*) 
    FROM PASSENGER 
    WHERE PClass = p.PClass 
        AND Survived = 1)*100.0/
    (SELECT count(*) 
    FROM PASSENGER 
    WHERE PClass = p.PClass),2) as taux_survivants 
FROM PASSENGER p 
ORDER BY PClass
;

/* (b) Taux de survivants par classe dans la catégorie enfants */

/* Requête pous savoir combien de personne par classe */

select pclass, count(*) as nb_pers_par_classe
from passenger 
where age<12
group by pclass
;

/* Requêtes pour avoir le nombre de survivants par classe */

select pclass, count(*) as nb_surv_par_classe
from passenger 
where age<12 and survived=1
group by pclass
;

/* Requêtes principales */


SELECT DISTINCT PClass, round(
    (SELECT count(*) 
    FROM PASSENGER 
    WHERE Age < 12 
        AND PClass = p.PClass 
        AND Survived = 1)*100.0
    /
    (SELECT count(*) 
    FROM PASSENGER 
    WHERE Age < 12 
        AND PClass = p.PClass),2) as taux_survivants_enfants 
FROM PASSENGER p 
ORDER BY PClass
;

/* (c) Taux de survivants par classe dans la catégorie femmes */

/* Requête pous savoir combien de personne par classe */

select pclass, count(*) as nb_pers_par_classe
from passenger 
where age>=12 and sex='female'
group by pclass
;

/* Requêtes pour avoir le nombre de survivants par classe */

select pclass, count(*) as nb_surv_par_classe
from passenger 
where age>=12 and sex='female' and survived=1
group by pclass
;
/* requêtes principales */

SELECT DISTINCT PClass, round(
    (SELECT count(*) 
    FROM PASSENGER 
    WHERE PClass = p.PClass 
        AND Age >= 12 
        AND Sex = 'female' 
        AND Survived = 1)*100.0/
    (SELECT count(*) 
    FROM PASSENGER 
    WHERE PClass = p.PClass 
        AND Age >= 12 
        AND Sex = 'female')
    ,2) as taux_survivants_femme
FROM PASSENGER p 
ORDER BY PClass
;


/* (d) Taux de survivants par classe dans la catégorie hommes */

/* Requête pous savoir combien de personne par classe */

select pclass, count(*) as nb_pers_par_classe
from passenger 
where age>=12 and sex='male'
group by pclass
;

/* Requêtes pour avoir le nombre de survivants par classe */

select pclass, count(*) as nb_surv_par_classe
from passenger 
where age>=12 and sex='male' and survived=1
group by pclass
;
/* requêtes principales */

SELECT DISTINCT PClass, 
    ROUND(
        (SELECT COUNT(*) 
        FROM PASSENGER 
        WHERE PClass = p.PClass 
            AND Age >= 12 
            AND Sex = 'male' 
            AND Survived = 1) * 100.0 /
          (SELECT COUNT(*) 
          FROM PASSENGER 
          WHERE PClass = p.PClass 
            AND Age >= 12 
            AND Sex = 'male')
    , 2) as taux_survivants_homme 
FROM PASSENGER p 
ORDER BY PClass
;

/* FIN DE LA PARTIE A3 */


/* PARTIE A4 */

/* (a) Nombre total d'enfants et nombre d'enfants rescapés */

SELECT (SELECT count(*) as nombre_enfants 
    FROM PASSENGER 
    WHERE Age < 12
    ), (
    SELECT count(*) 
    FROM PASSENGER 
    WHERE PassengerId IN (
        SELECT PassengerId 
        FROM RESCUE) 
    AND Age < 12
    ) as nombre_enfants_rescapés
;

/* (b) Nombre d'enfants qui ont survécu parmi les enfants qui ont été rescapés */

SELECT count(*) as nombre_enfants_survecu_rescapés 
FROM PASSENGER 
WHERE PassengerId IN (
    SELECT PassengerId 
    FROM RESCUE) 
AND Age < 12 
AND Survived = 1
;

/* (c) Pour chaque classe de passagers : nombre d'enfants qui ont survécu parmi les enfants rescapés */

SELECT DISTINCT PClass,
(SELECT count(*) as nombre_enfants_survecu_rescapés 
FROM PASSENGER 
WHERE PassengerId IN (
        SELECT PassengerId 
        FROM RESCUE) 
    AND Age < 12 
    AND Survived = 1 
    AND PClass = p.PClass
)
FROM PASSENGER p
;

/* (d) Taux de rescapés parmi les passagers */

/* Nombre de rescapés parmis les passagers */

SELECT count(PassengerId)as nb_rescapés_passagers
FROM RESCUE;

/* Nombre de passagers du titanic */

SELECT count(PassengerId) as nb_passagers
FROM PASSENGER;

/* Requête principale */

SELECT round(
    (SELECT count(PassengerId) 
    FROM RESCUE)*100.0
    /
    (SELECT count(PassengerId) 
    FROM PASSENGER)
,2) as taux_rescapés
;

/* (e) Nombre de rescapés par catégorie de passager (enfant, femme ou homme) */

SELECT DISTINCT (
    SELECT count(*) 
    FROM PASSENGER 
    WHERE PassengerId IN (SELECT PassengerId FROM RESCUE) 
        AND Age >= 12 
        AND Sex = 'male' ) as nb_resc_homme, 
    (SELECT count(*) 
    FROM PASSENGER 
    WHERE PassengerId IN (SELECT PassengerId FROM RESCUE)  
        AND Age >= 12 
        AND Sex = 'female' ) as nb_resc_femme,
    (SELECT count(*) 
    FROM PASSENGER 
    WHERE PassengerId IN (SELECT PassengerId FROM RESCUE) 
        AND Age < 12  ) as nb_resc_enfant
FROM PASSENGER p;

/*(f) Nombre de survivants par catégorie de rescapés (enfant, femme ou homme)*/

SELECT DISTINCT (
    SELECT count(*) 
    FROM PASSENGER 
    WHERE PassengerId IN (SELECT PassengerId FROM RESCUE) 
        AND Age >= 12 
        AND Survived = 1 
        AND Sex = 'male' ) as nb_resc_surv_homme, 
    (SELECT count(*) 
    FROM PASSENGER 
    WHERE PassengerId IN (SELECT PassengerId FROM RESCUE)  
        AND Age >= 12 
        AND Survived = 1 
        AND Sex = 'female' ) as nb_resc_surv_femme,
    (SELECT count(*) 
    FROM PASSENGER 
    WHERE PassengerId IN (SELECT PassengerId FROM RESCUE) 
        AND Age < 12 
        AND Survived = 1 ) as nb_resc_surv_enfant
FROM PASSENGER p
;


/*(g) Nombre total de rescapés et taux de survivants par embarcation - résultat ordonné sur le code de l'embarcation*/

SELECT DISTINCT r.LifeBoatId,(
    SELECT count(PassengerId) as nb_pers_embarc 
    FROM RESCUE 
    WHERE LifeBoatId = r.LifeBoatId )as nb_rescape_embarcation,
    round(
        (SELECT count(*) 
        FROM RESCUE, PASSENGER p 
        WHERE LifeBoatId = r.LifeBoatId 
            AND p.PassengerId = RESCUE.PassengerId 
            AND Survived = 1)*100.0/
        (SELECT count(PassengerId) 
        FROM RESCUE 
        WHERE LifeBoatId = r.LifeBoatId ),2) as taux_survivants 
FROM RESCUE r
ORDER by r.LifeBoatId
;

/*(h) Pour chaque classe de passager, nombre d'enfants, nombre de femmes et nombre d'hommes qui ont survécu parmi les rescapés */

SELECT DISTINCT p.PClass, 
    (
        SELECT count(*) 
        FROM PASSENGER 
        WHERE PassengerId IN (
            SELECT PassengerId 
            FROM RESCUE) 
        AND Age >= 12 
        AND Survived = 1 
        AND Sex = 'male' 
        AND PClass = p.PClass 
    ) as nb_resc_surv_homme, 
    (
        SELECT count(*) 
        FROM PASSENGER 
        WHERE PassengerId IN (
            SELECT PassengerId 
            FROM RESCUE) 
        AND Age >= 12 
        AND Survived = 1 
        AND Sex = 'female' 
        AND PClass = p.PClass 
    ) as nb_resc_surv_femme,
    (
        SELECT count(*) 
        FROM PASSENGER 
        WHERE PassengerId IN (
            SELECT PassengerId 
            FROM RESCUE) 
        AND Age < 12 
        AND Survived = 1 
        AND PClass = p.PClass 
    ) as nb_resc_surv_enfant
FROM PASSENGER p
;

/* FIN DE LA PARTIE A4 */


/* REQUETES COMPLEMENTAIRES (À VOUS DE JOUER…) */

/* 1. Quid des domestiques répertoriés dans la base ?
- ont-ils tous été rescapés ?
- s'ils ont été rescapés, en est-il de même de leurs employeurs (si oui, dans des embarcations identiques ou
différentes) ?*/

SELECT PassengerId_Dom,(
    SELECT Survived 
    FROM PASSENGER 
    WHERE PassengerId=s.PassengerId_Dom and PassengerId IN (
        SELECT PassengerId_Dom 
        FROM SERVICE)
) as survie_dom
, (
    SELECT LifeBoatId 
    FROM RESCUE 
    WHERE PassengerId = s.PassengerId_Dom) as lifeboat_dom
,PassengerId_emp
,(
    SELECT Survived 
    FROM PASSENGER 
    WHERE PassengerId = s.PassengerId_emp 
) as survie_emp 
,(SELECT LifeBoatId 
    FROM RESCUE 
    WHERE PassengerId = s.PassengerId_emp) as lifeboat_emp
FROM SERVICE s, PASSENGER p
WHERE s.PassengerId_Dom = p.PassengerId 
ORDER BY PassengerId_emp
;


/* 2. Taux de rescapés ayant survécu selon la position des canaux sur le navire */

/* le nombre de surivant en fonction de la position et du side */
SELECT DISTINCT Position, Side, (
    SELECT count(RESCUE.PassengerId)
    FROM RESCUE, LIFEBOAT, PASSENGER 
    WHERE LIFEBOAT.LifeBoatId = RESCUE.LifeBoatId 
        AND RESCUE.PassengerId = PASSENGER.PassengerId 
        AND PASSENGER.Survived = 1 
        AND LIFEBOAT.Side = l.Side 
        AND LIFEBOAT.Position = l.Position)as nb_survivants_par_emplacement 
    FROM LIFEBOAT l 
    ORDER BY nb_survivants_par_emplacement DESC
;

/* requête principale */
SELECT DISTINCT Position, Side, round(
    (SELECT count(RESCUE.PassengerId)
        FROM RESCUE, LIFEBOAT, PASSENGER
        WHERE LIFEBOAT.LifeBoatId = RESCUE.LifeBoatId
            AND RESCUE.PassengerId = PASSENGER.PassengerId
            AND LIFEBOAT.Side = l.Side
            AND LIFEBOAT.Position = l.Position
            AND PASSENGER.survived=1)*100.0/
    (SELECT count(RESCUE.PassengerId)
        FROM RESCUE, LIFEBOAT, PASSENGER
        WHERE LIFEBOAT.LifeBoatId = RESCUE.LifeBoatId
            AND RESCUE.PassengerId = PASSENGER.PassengerId
            AND LIFEBOAT.Side = l.Side
            AND LIFEBOAT.Position = l.Position),2)as nb_survivants_par_emplacement
FROM LIFEBOAT l
ORDER BY nb_survivants_par_emplacement DESC
;

/* 3. Influence de l'heure de mise a l'eau des canaux de sauvetages */
/* Nombre de rescapés ayant survécu par heure de mise a l'eau */
 SELECT DISTINCT l.Launching_Time, (
    SELECT count(RESCUE.PassengerId)
    FROM RESCUE, PASSENGER, LIFEBOAT
    WHERE LIFEBOAT.Launching_Time = l.Launching_Time
    AND LIFEBOAT.LifeBoatId = RESCUE.LifeBoatId
    AND RESCUE.PassengerId = PASSENGER.PassengerId
    AND Survived = 1) as nb_surv
FROM LIFEBOAT l
ORDER BY Launching_Time DESC
;

/*Nombre de bateau par heure*/

select launching_time, count(LifeBoatId)as nb_bateau
from LIFEBOAT l 
group by l.Launching_Time
ORDER BY Launching_Time DESC;

/* 4. Taux de survie par tranche d'âge parmi les passagers ayant au moins 12 ans lors du naufrage */

SELECT Age, count(PassengerId) as nb_surv 
FROM PASSENGER 
WHERE Survived = 1 
    AND Age >= 12 
GROUP BY Age
ORDER BY nb_surv desc, age
;

/* 5. Combien de passagers supplémentaires auraient pu être rescapés (et peut-être survivre) si le taux
maximum de remplissage des embarcations de sauvetage avait été respecté ? */

SELECT (
    select count(*)as nombre_de_passager 
    from PASSENGER)
    
    ,
    count(PassengerId)as nb_sauvés
    
    ,(
    SELECT sum(Places) 
    FROM CATEGORY c, LIFEBOAT l 
    WHERE c.LifeBoatCat = l.LifeBoatCat) as nb_aurait_pu_etre_sauvés_totale
    
    ,(
    select count(*) 
    from PASSENGER)
    -(
    SELECT sum(Places) 
    FROM CATEGORY c, LIFEBOAT l 
    WHERE c.LifeBoatCat = l.LifeBoatCat)as nb_mort_quoiquil_arrive
FROM RESCUE
;