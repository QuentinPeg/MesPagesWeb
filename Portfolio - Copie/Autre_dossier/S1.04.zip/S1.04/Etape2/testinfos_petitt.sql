/*
les informations relatives au passager n°916 : son nom, son âge, sa classe, sa ou ses cabines, le nom du port où il a
embarqué, numéro et catégorie de l'embarcation de sauvetage qui l'a éventuellement secouru
*/

SELECT p.Name, p.Age, p.PClass,o.CabinCode,po.PortName,l.lifeboatId,l.lifeboatcat 
FROM PASSENGER p, PORT po, OCCUPATION o, LIFEBOAT l, RESCUE r 
WHERE p.PassengerId = 916 
    AND p.PortId = po.PortId 
    AND p.PassengerId = o.PassengerID 
    AND p.PassengerId = r.PassengerId 
    AND r.lifeboatid = l.lifeboatId;

/* si le nom et le rôle des domestiques du passager n°1264 est exact*/

SELECT p.Name, s.Role 
FROM PASSENGER p, SERVICE s 
WHERE p.PassengerId = 1264 
    AND p.PassengerId = s.PassengerId_Emp;

/*si la liste des passagers ayant été secourus par le canot n°7 est exacte*/

SELECT P.Name 
FROM PASSENGER p, RESCUE r 
WHERE p.passengerId = r.PassengerId 
    AND r.lifeboatid = '7';


