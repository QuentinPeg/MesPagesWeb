CREATE TABLE PORT(
  PortId char(1) primary key,
  PortName varchar NOT NULL,
  Country varchar NOT NULL,
  CONSTRAINT port_id CHECK(PortId IN ('C','Q','S'))
);

CREATE TABLE PASSENGER(
  PassengerId int primary key,
  Name varchar NOT NULL,
  Sex varchar NOT NULL,
  Age int,
  Survived int CHECK (Survived IN ('0','1')) DEFAULT '0',
  PClass int NOT NULL CHECK (PClass >= 1 AND PClass <= 3),
  PortId char(1) references PORT(PortId)
);

CREATE TABLE OCCUPATION(
  PassengerId int references PASSENGER(PassengerId),
  CabinCode varchar,
  primary key (PassengerId,CabinCode)
);

CREATE TABLE SERVICE(
  PassengerId_Emp int NOT NULL,
  PassengerId_DOM int primary key,
  Role varchar NOT NULL,
  foreign key (passengerid_dom) references PASSENGER(PassengerId),
  foreign key (PassengerId_Emp) references PASSENGER(PassengerId)
);

CREATE TABLE CATEGORY(
  LifeBoatCat varchar CHECK (LifeBoatCat IN ('standard','secours','radeau')),
  Structure varchar NOT NULL CHECK (Structure IN ('bois','bois et toile')), 
  Places int NOT NULL,
  primary key(LifeBoatCat)
);

CREATE TABLE LIFEBOAT(
  LifeBoatId varchar primary key, 
  LifeBoatCat varchar references CATEGORY(LifeBoatCat),
  Side varchar NOT NULL CHECK (Side IN ('babord','tribord')),
  Position varchar NOT NULL CHECK (Position IN ('avant','arriere')),
  Location varchar NOT NULL DEFAULT 'pont',
  Launching_Time Time NOT NULL
);

CREATE TABLE RECOVERY(
 LifeBoatId varchar references LIFEBOAT(LifeBoatId),
 Recovery_Time Time NOT NULL,
 primary key(LifeBoatId)
);

CREATE TABLE RESCUE(
 PassengerId int references PASSENGER(PassengerId),
 LifeBoatId varchar NOT NULL,
 primary key(PassengerId) 
);
