/* PARTIE PORT */

/* test n°1 si l'id de port est bien dans : (C,Q ou S) */
INSERT INTO PORT VALUES ('V','Port1','Pays1');
/*
psql:testConfo_petitt.sql:7: ERROR:  new row for relation "port" violates check constraint "port_id"
DETAIL:  Failing row contains (V, Port1, Pays1).
*/

/* test n°2 si un int peut être mis pour l'id du port */
INSERT INTO PORT VALUES (5,'Port1','Pays1');
/*
ERROR:  new row for relation "port" violates check constraint "port_id"
DETAIL:  Failing row contains (5, Port1, Pays1).
*/

/* test n°3 si deux caractères peuvent être mis pour l'id du port */
INSERT INTO PORT VALUES ('CQ','Port1','Pays1');
/*
ERROR:  value too long for type character(1)
*/


/* test n°4 si l'attribut port id peut ne pas être renseigné : est-ce que c'est bien une clé primaire*/
INSERT INTO PORT(PortName,Country) VALUES ('Port1','Pays1');
/*
ERROR:  null value in column "portid" of relation "port" violates not-null constraint
DETAIL:  Failing row contains (null, Port1, Pays1).
*/

/* test n°5 si PortName peut ne pas être renseigné */

INSERT INTO PORT(PortId,Country) VALUES ('C','Pays1');
/*
ERROR:  null value in column "portname" of relation "port" violates not-null constraint
DETAIL:  Failing row contains (C, null, Pays1).
*/

/* test n°6 si Country peut ne pas être renseigné */
INSERT INTO PORT(PortId, PortName) VALUES ('C','Port1');
/*
ERROR:  null value in column "country" of relation "port" violates not-null constraint
DETAIL:  Failing row contains (C, Port1, null).
*/
/* FIN DE LA PARTIE PORT */

/* PARTIE PASSENGER */

 /* test n°7 si passengerId est bien en tant que clé primaire*/

INSERT INTO PASSENGER(Name,Sex,Age,Survived,PClass,PortID) VALUES ('Passager 1','Sex1',23,1,1,'C');
/*
ERROR:  null value in column "passengerid" of relation "passenger" violates not-null constraint
DETAIL:  Failing row contains (null, Passager 1, Sex1, 23, 1, 1, C).
*/

/* test n°8 si l'on peut mettre autre chose qu'un int dans passengerId */
INSERT INTO PASSENGER(passengerId,name,Sex,Age,Survived,Pclass,PortID)VALUES('pasunentier','Passager1','Sex1',23,1,1,'C');
/*
ERROR:  invalid input syntax for type integer: "pasunentier"
LINE 2: ...ngerId,name,Sex,Age,Survived,Pclass,PortID)VALUES('pasunenti...').
*/

 /* test n°9 si l'attribut name peut ne pas être renseigné */
 
INSERT INTO PASSENGER(passengerId,Sex,Age,Survived,Pclass,PortId) VALUES (13,'Sex1',23,1,1,'C');
/*
ERROR:  null value in column "name" of relation "passenger" violates not-null constraint
DETAIL:  Failing row contains (13, null, Sex1, 23, 1, 1, C).
*/

 /* test n°10 si l'attribut sex peut ne pas être renseigné */


INSERT INTO PASSENGER(passengerId,Name,Age,Survived,Pclass,PortId) VALUES (13,'Passager 1',23,1,1,'C');
/*
ERROR:  null value in column "sex" of relation "passenger" violates not-null constraint
DETAIL:  Failing row contains (13, Passager 1, null, 23, 1, 1, C).
*/

/* test n°11 si on met autre chose qu'un int dans age */
INSERT INTO PASSENGER VALUES (23,'Passager 1','Sex1','Age1',1,1,'C');
/*
ERROR:  invalid input syntax for type integer: "Age1"
*/
/* test n°12 si ont met autre chose qu'un int dans Survived */
INSERT INTO PASSENGER VALUES (23,'Passager 1','Sex1',23,'s',1,'C');
/*
ERROR:  invalid input syntax for type integer: "s"
*/

 /* test n°13 sur le survived si on peut mettre autre chose que 0 ou 1 */
INSERT INTO PASSENGER VALUES (23,'Passager 1','Sex1',23,4,1,'C');
/*
ERROR:  new row for relation "passenger" violates check constraint "passenger_survived_check"
DETAIL:  Failing row contains (23, Passager 1, Sex1, 23, 4, 1, C).
*/

 /* test n°14 si l'attribut Pclass peut ne pas être renseigné */
INSERT INTO PASSENGER(passengerId,Name,Sex,Age,Survived,PortId) VALUES (13,'Passager 1','Sex1',23,1,'C');
/*
ERROR:  null value in column "pclass" of relation "passenger" violates not-null constraint
DETAIL:  Failing row contains (13, Passager 1, Sex1, 23, 1, null, C).
*/

 /* test n°15 sur la classe du passager(Pclass) si on peut mettre autre chose qu'un int */
INSERT INTO PASSENGER VALUES (23,'Passager 1','Sex1',23,1,'n','C');
/*
ERROR:  invalid input syntax for type integer: "n"
*/

 /* test n°16 sur le PClass pour une valeur non comprise entre 1 et 3 */
INSERT INTO PASSENGER VALUES (23,'Passager 1','Sex1',23,1,5,'C');
/*
ERROR:  new row for relation "passenger" violates check constraint "passenger_pclass_check"
DETAIL:  Failing row contains (23, Passager 1, Sex1, 23, 1, 5, C).
*/

/* FIN DE LA PARTIE PASSENGER */


/* PARTIE OCCUPATION */

/* test n°17 si l'attribut passenger id n'est pas renseigné */
INSERT INTO OCCUPATION (CabinCode) VALUES ('ez23');
/*
ERROR:  null value in column "passengerid" of relation "occupation" violates not-null constraint
DETAIL:  Failing row contains (null, ez23).
*/

 /* test n°18 si l'on ne renseigne pas le cabinCode */
INSERT INTO OCCUPATION (passengerId) VALUES (123456);
/*
ERROR:  null value in column "cabincode" of relation "occupation" violates not-null constraint
DETAIL:  Failing row contains (123456, null).
*/

/* FIN DE LA PARTIE OCCUPATION */

/* PARTIE SERVICE */

/* test n°19 si l'on ne renseigne pas l'attribut passengerid_emp *//* prblmmmmmmmmmmmmmmmmmmmmmmm*/
INSERT INTO SERVICE (passengerid_dom,PassengerId_Emp,role) VALUES (123456,null,'chauffer');

/* test n°20 si l'on renseigne pas le passengerId domestique */
INSERT INTO SERVICE (passengerid_emp,role) VALUES (123456,'chauffeur');
/*
ERROR:  null value in column "passengerid_dom" of relation "service" violates not-null constraint
DETAIL:  Failing row contains (null, 123456, chauffeur).
*/

/* test n°21 si l'on ne renseigne pas le role du domestique */
INSERT INTO SERVICE (passengerid_dom,passengerid_emp) VALUES (123456,124);
/*
ERROR:  null value in column "role" of relation "service" violates not-null constraint
DETAIL:  Failing row contains (123456, 124, null).
*/

/*FIN DE LA PARTIE SERVICE*/


/* PARTIE CATEGORY */

 /* test n°22 si Places peut ne pas être renseigné*/
INSERT INTO CATEGORY (LifeBoatCat,Structure) VALUES ('standard','bois et toile');
/*
ERROR:  null value in column "places" of relation "category" violates not-null constraint
DETAIL:  Failing row contains (standard, bois et toile, null).
*/

 /* test n°23 si Structure peut ne pas être renseigné*/
INSERT INTO CATEGORY (LifeBoatCat,Places) VALUES ('standard',5);
/*
ERROR:  null value in column "structure" of relation "category" violates not-null constraint
DETAIL:  Failing row contains (standard, null, 5).
*/

/* test n°24 si LifeBoatCat peut ne pas être renseigné*/
INSERT INTO CATEGORY (Structure,Places) VALUES ('bois',5);
/*
ERROR:  null value in column "lifeboatcat" of relation "category" violates not-null constraint
DETAIL:  Failing row contains (null, bois, 5).
*/

 /* test n°25 si Places n'est pas un int*/
INSERT INTO CATEGORY (LifeBoatCat,Structure,Places) VALUES ('standard','bois et toile','pasunentier');
/*
ERROR:  invalid input syntax for type integer: "pasunentier"
*/

/* test n°26 si dans Structure autre chose que 'bois' ou 'bois et toile' est saisie*/
INSERT INTO CATEGORY (LifeBoatCat,Structure,Places) VALUES ('standard','toile',5);
/*
ERROR:  new row for relation "category" violates check constraint "category_structure_check"
DETAIL:  Failing row contains (standard, toile, 5).
*/

 /* test n°27 si dans LifeBoatCat autre chose que 'standard','secours ou 'radeau' est saisie*/
INSERT INTO CATEGORY (LifeBoatCat,Structure,Places) VALUES ('test','bois et toile',5);
/*
ERROR:  new row for relation "category" violates check constraint "category_lifeboatcat_check"
DETAIL:  Failing row contains (test, bois et toile, 5).
*/

/* FIN DE LA PARTIE CATEGORY */


/* PARTIE LIFEBOAT */

/* test n°28 si LifeBoatId peut être null */
INSERT INTO LIFEBOAT (LifeBoatId,Side,Position,Location,Launching_Time) VALUES (null,'tribord','avant','pont','12:10:00');
/*
ERROR:  null value in column "lifeboatid" of relation "lifeboat" violates not-null constraint
DETAIL:  Failing row contains (null, null, tribord, avant, pont, 12:10:00).
*/

 /* test n°29 si Side n'est pas rempli */
INSERT INTO LIFEBOAT (LifeBoatId,Position,Location,Launching_Time) VALUES (123456,'avant','pont','12:10:00');
/*
ERROR:  null value in column "side" of relation "lifeboat" violates not-null constraint
DETAIL:  Failing row contains (123456, null, null, avant, pont, 12:10:00).
*/

/* test n°30 si Side contient autre chose que 'tribord' ou 'tribord' */
INSERT INTO LIFEBOAT (LifeBoatId,Side,Position,Location,Launching_Time) VALUES (123456,'droitor','avant','pont','12:10:00');
/*
ERROR:  new row for relation "lifeboat" violates check constraint "lifeboat_side_check"
DETAIL:  Failing row contains (123456, null, droitor, avant, pont, 12:10:00).
*/

 /* test n°31 si Position n'est pas rempli */
INSERT INTO LIFEBOAT (LifeBoatId,Side,Location,Launching_Time) VALUES (123456,'tribord','pont','12:10:00');
/*
ERROR:  null value in column "position" of relation "lifeboat" violates not-null constraint
DETAIL:  Failing row contains (123456, null, tribord, null, pont, 12:10:00).
*/

 /* test n°32 si Position contient autre chose que 'avant' ou 'arrière' */
INSERT INTO LIFEBOAT (LifeBoatId,Side,Position,Location,Launching_Time) VALUES (123456,'tribord','droite','pont','12:10:00');
/*
ERROR:  new row for relation "lifeboat" violates check constraint "lifeboat_position_check"
DETAIL:  Failing row contains (123456, null, tribord, droite, pont, 12:10:00).
*/

/* test n°33 si Location est null */
INSERT INTO LIFEBOAT (LifeBoatId,Side,Position,Location,Launching_Time) VALUES (123456,'tribord','avant',null,'12:10:00');
/*
ERROR:  null value in column "location" of relation "lifeboat" violates not-null constraint
DETAIL:  Failing row contains (123456, null, tribord, avant, null, 12:10:00).
*/

/* test n°34 si Launching_Time n'est pas rempli */
INSERT INTO LIFEBOAT (LifeBoatId,Side,Position,Location) VALUES (123456,'tribord','avant','pont');
/*
ERROR:  null value in column "launching_time" of relation "lifeboat" violates not-null constraint
DETAIL:  Failing row contains (123456, null, tribord, avant, pont, null).
*/

/* test n°35 si Launching_Time contient autre chose que un type time */
INSERT INTO LIFEBOAT (LifeBoatId,Side,Position,Location,Launching_Time) VALUES (123456,'tribord','avant','pont','coucou');
/*
ERROR:  invalid input syntax for type time: "coucou"
LINE 2: ...ing_Time) VALUES (123456,'tribord','avant','pont','coucou');
*/

/* FIN DE LA PARTIE LIFEBOAT */


/* PARTIE RECOVERY */

 /* test n°36 si l'on ne renseigne LifeBoatId */
INSERT INTO RECOVERY (Recovery_Time) VALUES ('18:12:20');
/*
ERROR:  null value in column "lifeboatid" of relation "recovery" violates not-null constraint
DETAIL:  Failing row contains (null, 18:12:20).
*/

 /* test n°37 si l'on ne met pas un type Time */
INSERT INTO RECOVERY (LifeBoatId,Recovery_Time) VALUES (5,'pasuntime');
/*
ERROR:  invalid input syntax for type time: "pasuntime"
LINE 2: ...NTO RECOVERY (LifeBoatId,Recovery_Time) VALUES (5,'pasuntime...')
*/

 /* test n°38 si l'on met un null dans Recovery_Time */
INSERT INTO RECOVERY (LifeBoatId,Recovery_Time) VALUES (5,null);
/*
ERROR:  null value in column "recovery_time" of relation "recovery" violates not-null constraint
DETAIL:  Failing row contains (5, null).
*/

/* FIN DE LA PARTIE RECOVERY */


/* PARTIE RESCUE */

 /* test n°39 si l'on met un null dans LifeBoatId */
INSERT INTO RESCUE(PassengerID,LifeBoatId) VALUES (4,null);
/*
ERROR:  null value in column "lifeboatid" of relation "rescue" violates not-null constraint
DETAIL:  Failing row contains (4, null).
*/

/* test n°40 si l'on ne met pas un entier dans PassengerId */
INSERT INTO RESCUE (PassengerID,LifeBoatId) VALUES ('pasunentier',4);
/*
ERROR:  invalid input syntax for type integer: "pasunentier"
LINE 2: ...SERT INTO RESCUE (PassengerID,LifeBoatId) VALUES ('pasunenti...')
*/

/* test n°41 si null dans PassengerId*/
INSERT INTO RESCUE(PassengerID,LifeBoatId) VALUES (null, 4);
/*
ERROR:  null value in column "passengerid" of relation "rescue" violates not-null constraint
DETAIL:  Failing row contains (null, 4).
*/

/* FIN DE LA PARTIE RESCUE */