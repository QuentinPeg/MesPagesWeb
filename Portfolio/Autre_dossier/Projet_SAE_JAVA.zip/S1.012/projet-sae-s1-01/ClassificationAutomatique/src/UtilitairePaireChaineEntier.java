import java.util.ArrayList;
public class UtilitairePaireChaineEntier {

    public static int indicePourChaine(ArrayList<PaireChaineEntier> listePaires, String chaine) {
        if (listePaires.isEmpty() || listePaires.get(listePaires.size()-1).getChaine().compareTo(chaine) < 0){
            return -1;
        }else {
            int m,sup = listePaires.size(),inf = 0;
            while (inf < sup){
                m = (sup+inf)/2;
                if (listePaires.get(m).getChaine().compareTo(chaine) >= 0){
                    sup = m;
                }else {
                    inf = m+1;
                }
            }
            return listePaires.get(sup).getChaine().equals(chaine) ? sup : -1;
        }
    }
    /*
public static int indicePourChaineIter(ArrayList<PaireChaineEntier> listePaires, String chaine) {
    int i = 0;
    while (i < listePaires.size() && !listePaires.get(i).equals(chaine)){
        i++;
    }
    return i < listePaires.size() ? i : -1;
}
*/

    public static int entierPourChaine(ArrayList<PaireChaineEntier> listePaires, String chaine) {
        if (listePaires.isEmpty() || listePaires.get(listePaires.size()-1).getChaine().compareTo(chaine) < 0){
            return -1;
        }else {
            int m,sup = listePaires.size(),inf = 0;
            while (inf < sup){
                m = (sup+inf)/2;
                if (listePaires.get(m).getChaine().compareTo(chaine) >= 0){
                    sup = m;
                }else {
                    inf = m+1;
                }
            }
            return listePaires.get(sup).getChaine().equals(chaine) ? listePaires.get(sup).getEntier() : 0;
        }
    }
    public static int entierPourChaineIter(ArrayList<PaireChaineEntier> listePaires, String chaine) {
        int i = 0;
        while (i < listePaires.size() && !listePaires.get(i).getChaine().equals(chaine)){
            i++;
        }
        return i < listePaires.size() ? listePaires.get(i).getEntier() : 0;
    }
    public static String chaineMax(ArrayList<PaireChaineEntier> listePaires) {
        int max = 0;
        for (int i = 1; i < listePaires.size();i++){
            if (listePaires.get(i).getEntier() > listePaires.get(max).getEntier()){
                max = i;
            }
        }
        return listePaires.get(max).getChaine();
    }

    private static void insereTri(ArrayList<PaireChaineEntier> paireChaineEntiers, PaireChaineEntier score){
        int i = 0;
        while (i < paireChaineEntiers.size() && paireChaineEntiers.get(i).getEntier() < score.getEntier()){
            i++;
        }
        paireChaineEntiers.add(i, score);
    }
    public static String ClassementKNNDepeche(ArrayList<Depeche> lesDepeches, int indiceDepecheCours){
        ArrayList<PaireChaineEntier> ScoreCategorieDep = new ArrayList<>();
        for (int k = indiceDepecheCours+1;k < lesDepeches.size();k++){
            insereTri(ScoreCategorieDep,ressemblence(lesDepeches.get(indiceDepecheCours), lesDepeches.get(k)));
        }for (int j = indiceDepecheCours-1;j > 0;j--){
            insereTri(ScoreCategorieDep,ressemblence(lesDepeches.get(indiceDepecheCours), lesDepeches.get(j)));
        }
        if(ScoreCategorieDep.get(ScoreCategorieDep.size()-1).getChaine().equals(ScoreCategorieDep.get(ScoreCategorieDep.size()-2).getChaine()) ||
                ScoreCategorieDep.get(ScoreCategorieDep.size()-1).getChaine().equals(ScoreCategorieDep.get(ScoreCategorieDep.size()-3).getChaine())){
            return ScoreCategorieDep.get(ScoreCategorieDep.size()-1).getChaine();
        }else if(ScoreCategorieDep.get(ScoreCategorieDep.size()-2).getChaine().equals(ScoreCategorieDep.get(ScoreCategorieDep.size()-3).getChaine())){
            return ScoreCategorieDep.get(ScoreCategorieDep.size()-2).getChaine();
        }else {
            return ScoreCategorieDep.get(ScoreCategorieDep.size()-3).getChaine();
        }
    }
    private static PaireChaineEntier ressemblence(Depeche depeche1, Depeche depeche2){
        int ressem = 0;
        for (String mot1: depeche1.getMots()){
            for (String mot2: depeche2.getMots()){
                if (mot1.length() > 4 && mot2.equals(mot1)) {ressem++;}
            }
        }
        return new PaireChaineEntier(depeche2.getCategorie(),ressem);
    }
}